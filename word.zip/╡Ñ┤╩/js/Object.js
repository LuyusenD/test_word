var word_text = function(){
	this.word = {},
	this.static = 0
	
}
word_text.prototype.init=function(val=0){
	if(localStorage["word"] == undefined)
		localStorage["word"] = '';
	if(localStorage["test"] == undefined)
		localStorage["test"] = '';
		
	
}
word_text.prototype.getWord=function(elem=localStorage['word']){
	var val = elem.split(" ").slice(0,-1);
	for(var i=0;i<val.length;i+=2){
		this.word[val[i]] = val[i+1];
	}
}
word_text.prototype.addWord=function(elem){
	this.init()
	localStorage["word"] += `${elem} `
}
word_text.prototype.setalert=function(content=''){
	var html = `
		<div id="alert">
			<div class="bg"></div>
			<div class="alert">
				<span>${content}</span>
				<button>确定</button>
			</div>
		</div>`;
	$('body').append(html)
	$('#alert button').click(function(){
		$('#alert').remove()
	})
}

word_text.prototype.teststatic=function(i=0){
	localStorage['testStatic'] = i
}
word_text.prototype.testWord=function(get,post){
	var ok = 0;
	var err = 0;
	for(var i=0;i<post.length;i++){
		if(this.word[post[i]]==get[i]){
			console.log(post[i]+"正确")
			ok++
		}else{
			console.log(post[i]+"错误")
			err++
		}

	}
	var static = localStorage['testStatic']
	if(static>0){
		localStorage["test"] += `${ok},${err};`
		localStorage["testStatic"] = 0
		
	}

}